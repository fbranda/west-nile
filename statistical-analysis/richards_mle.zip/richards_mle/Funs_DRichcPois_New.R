# Packages ----------------------------------------------------------------

library(MASS)
library(rmutil)
library(numDeriv)
require(tidyverse)
require(magrittr)
source("richards_mle/Funs_DRichcNew.R")

# Functions - Poisson -----------------------------------------------------

# Likelihood
likPois <- function(pars, ti, di, X, off) 
{
  npars <- length(pars)
  ncovs <- ncol(X)
  richpars <- pars[1:(npars-ncovs-1)]
  betapars <- pars[(npars-ncovs):(npars-1)]
  logbase <- pars[npars]
  
  linPred <- exp(log(off)  + X%*%betapars + 
                   log(exp(logbase) + exp(ldRich(pars=richpars, ti=ti))))
  
  out <- sum(dpois(di, linPred, log=T))
  
  return(out)
}

# Gradient Richard-Poisson
PoisdRichGradient <- function(pars, ti, di, X, off)
{
  # Parameters
  npars <- length(pars)
  ncovs <- ncol(X)
  nrich <- (npars-ncovs-1)
  richpars <- pars[1:nrich]
  betapars <- pars[(nrich+1):(npars-1)]
  logbase <- pars[npars]
  loff <- log(off)
  
  # Linear predictor
  llambdat <- ldRich(pars=richpars, ti=ti)
  lambdat <- exp(llambdat)
  Xb <- X%*%betapars
  eXb <- exp(Xb)
  lmut <- loff + Xb + log(exp(logbase)+lambdat)
  mut <- exp(lmut)
  
  # First derivatives
  d1lt <- d1dRich(pars=richpars, ti=ti)
  d1eXb <- c(eXb)*X
  d1logb <- rep(exp(logbase), length(ti))
  d1mut <- off * cbind(c(eXb)*d1lt, c(exp(logbase) + lambdat)*d1eXb, c(eXb)*d1logb)
  
  # Auxiliary
  aux1 <- exp(log(di)-lmut)
  
  # Gradient computation
  out <- colSums(c(aux1-1)*d1mut)
  
  return(out)
}

