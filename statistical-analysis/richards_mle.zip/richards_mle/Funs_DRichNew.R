# Packages ----------------------------------------------------------------

library(MASS)
require(tidyverse)
require(magrittr)


# Functions - Richards -----------------------------------------------------

# Log-Richards
lRich <- function(pars, ti, Log=T)
{
  # Parameters
  logr <- pars[1]
  r <- exp(logr)
  logh <- pars[2]
  h <- exp(logh)
  p <- pars[3]
  logs <- pars[4]
  s <- exp(logs)
  
  le <- h*(p-ti)
  l1pe <- log1p(exp(le))
  l1pe <- ifelse(is.infinite(l1pe), le, l1pe)
  l1pe <- ifelse(exp(h*(p-ti)) < 10^(-14), exp(le), l1pe)
  
  out <- logr - s*l1pe
  
  if (!Log) out <- exp(out)
  
  return(out)
}


# Linearization of Richards' differences
ldRich <- function(pars, ti, Log=T)
{
  logr <- pars[1]
  r <- exp(logr)
  logh <- pars[2]
  h <- exp(logh)
  p <- pars[3]
  logs <- pars[4]
  s <- exp(logs)
  
  tdiff <- diff(ti)[1]
  if (length(ti)==1)
  {
    tdiff <- 1
  }
  ti <- ti-tdiff/2
  
  le <- h*(p-ti)
  l1pe <- log1p(exp(le))
  l1pe <- ifelse(is.infinite(l1pe), le, l1pe)
  l1pe <- ifelse(exp(h*(p-ti)) < 10^(-14), exp(le), l1pe)
  
  out <- logr+log(s)+logh+h*(p-ti)-(s+1)*l1pe+log(tdiff)
  
  if (!Log) out <- exp(out)
  
  return(out)
}


# First derivatives
d1dRich <- function(pars, ti)
{
  # Parameters
  logr <- pars[1]
  r <- exp(logr)
  logh <- pars[2]
  h <- exp(logh)
  p <- pars[3]
  logs <- pars[4]
  s <- exp(logs)
  
  tdiff <- diff(ti)[1]
  if (length(ti)==1)
  {
    tdiff <- 1
  }
  ti <- ti-tdiff/2
  
  # Auxiliary
  le <- h*(p-ti)
  l1pe <- log1p(exp(le))
  l1pe <- ifelse(is.infinite(l1pe), le, l1pe)
  l1pe <- ifelse(exp(h*(p-ti)) < 10^(-14), exp(le), l1pe)
  
  # First derivatives
  
  # r
  dlr <- exp( logh + logs + le - (s+1) * l1pe ) * r * tdiff
  
  # h
  dlh <- exp( logr + logs + le - (s+1) * l1pe ) * 
    ( 1 + le * ( 1 - exp(log(s+1) - l1pe + le ) ) ) * h * tdiff
  
  # -s * h *               # Jacobian
  # diff((p-tAll) * exp(lehpt - (s+1) * l1pehpt))
  
  # p
  dlp <- exp( logr + 2*logh + logs + le - (s+1)*l1pe ) * 
    (  1 - exp( log(s+1) - l1pe + le ) ) * tdiff
  # s  
  dls <- exp ( logr + logh + le - (s+1)*l1pe) * ( 1 - s*l1pe) * s * tdiff
  
  out <- matrix(c(dlr, dlh, dlp, dls), nrow=length(ti), ncol=4)
  
  return(out)
}


# Functions Richards centered ---------------------------------------------

# # Log-Richards centered
lRichc <- function(pars, ti, Log=T)
{
  # Parameters
  logr <- pars[1]
  r <- exp(logr)
  logh <- pars[2]
  h <- exp(logh)
  c <- pars[3]
  logs <- pars[4]
  s <- exp(logs)
  
  le <- h*(c-ti)
  l1pe <- log1p(exp(le-logs))
  l1pe <- ifelse(is.infinite(l1pe), le-logs, l1pe)
  l1pe <- ifelse(exp(le-logs) < 10^(-14), exp(le-logs), l1pe)
  
  out <- logr - s*l1pe
  
  if (!Log) out <- exp(out)
  
  return(out)
}

# Linearization of Richards' differences centered
ldRichc <- function(pars, ti, Log=T)
{
  logr <- pars[1]
  r <- exp(logr)
  logh <- pars[2]
  h <- exp(logh)
  c <- pars[3]
  logs <- pars[4]
  s <- exp(logs)
  
  tdiff <- diff(ti)[1]
  if (length(ti)==1)
  {
    tdiff <- 1
  }
  ti <- ti-tdiff/2
  
  le <- h*(c-ti)
  l1pe <- log1p(exp(le-logs))
  l1pe <- ifelse(is.infinite(l1pe), le-logs, l1pe)
  l1pe <- ifelse(exp(le-logs) < 10^(-14), exp(le-logs), l1pe)
  
  out <- logr+logh+le-(s+1)*l1pe+log(tdiff)
  
  if (!Log) out <- exp(out)
  
  return(out)
}

# First derivatives
d1dRichc <- function(pars, ti)
{
  # Parameters
  logr <- pars[1]
  r <- exp(logr)
  logh <- pars[2]
  h <- exp(logh)
  c <- pars[3]
  logs <- pars[4]
  s <- exp(logs)
  
  tdiff <- diff(ti)[1]
  if (length(ti)==1)
  {
    tdiff <- 1
  }
  ti <- ti-tdiff/2
  
  # Auxiliary
  le <- h*(c-ti)
  l1pe <- log1p(exp(le-logs))
  l1pe <- ifelse(is.infinite(l1pe), le-logs, l1pe)
  l1pe <- ifelse(exp(le-logs) < 10^(-14), exp(le-logs), l1pe)
  
  # First derivatives
  
  # r
  dlr <- exp( logh + le - (s+1) * l1pe ) * r * tdiff
  
  # h
  dlh <- exp( logr + le - (s+1) * l1pe ) * 
    ( 1 + le * ( 1 - exp(log(s+1) - l1pe + le - logs ) ) ) * h * tdiff
  
  # -s * h *               # Jacobian
  # diff((p-tAll) * exp(lehpt - (s+1) * l1pehpt))
  
  # p
  dlc <- exp( logr + 2*logh + le - (s+1)*l1pe ) * 
    (  1 - exp( log(s+1) - l1pe + le - logs) ) * tdiff
  # s  
  dls <- exp ( logr + logh + le - (s+1)*l1pe) * ( exp(log(s+1)-2*logs + le - l1pe) - l1pe ) * s * tdiff
  
  out <- matrix(c(dlr, dlh, dlc, dls), nrow=length(ti), ncol=4)
  
  return(out)
}

