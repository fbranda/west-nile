# Packages ----------------------------------------------------------------

library(MASS)
library(rmutil)
library(numDeriv)
require(tidyverse)
require(magrittr)
source("richards_mle/Funs_DRichNew.R")

# Functions Negative Binomial ---------------------------------------------

# Likelihood
likNB <- function(pars, ti, di, X, off) 
{
  npars <- length(pars)
  ncovs <- ncol(X)
  nrich <- npars-ncovs-2
  richpars <- pars[1:nrich]
  betapars <- pars[(nrich+1):(npars-2)]
  logbase <- pars[npars-1]
  n <- exp(pars[npars])
  loff <- log(off)
  
  linPred <- exp(loff + X%*%betapars + log(exp(logbase)+exp(ldRich(pars=richpars, ti=ti))))
  
  out <- sum(dnbinom(di, size=n, mu=linPred, log=T))
  
  return(out)
}

# Functions Negative Binomial - Richards ---------------------------------------------

NBdRichGradient <- function(pars, ti, di, X, off)
{
  # Parameters
  npars <- length(pars)
  ncovs <- ncol(X)
  nrich <- npars-ncovs-2
  richpars <- pars[1:nrich]
  betapars <- pars[(nrich+1):(npars-2)]
  logbase <- pars[npars-1]
  n <- exp(pars[npars])
  loff <- log(off)
  
  # Linear predictor
  llambdat <- ldRich(pars=richpars, ti=ti)
  lambdat <- exp(llambdat)
  Xb <- X%*%betapars
  eXb <- exp(Xb)
  lmut <- loff + X%*%betapars + log(exp(logbase)+exp(ldRich(pars=richpars, ti=ti)))
  mut <- exp(lmut)

  # First derivatives
  d1lt <- d1dRich(richpars, ti)
  d1eXb <- c(eXb)*X
  d1logb <- rep(exp(logbase), length(ti))
  d1mut <- off*cbind(c(eXb)*d1lt, c(exp(logbase) + lambdat)*d1eXb, c(eXb)*d1logb)
  d1n <- (log(n) - digamma(n) + digamma(n+di) - log(mut+n) + (mut-di)/(mut+n)) * n
  
  # Auxiliary
  aux1 <- exp(log(n+di)-log(mut+n))
  aux2 <- exp(log(di)-lmut)
  
  # Gradient computation
  out <- c(colSums(-c(aux1)*d1mut+c(aux2)*d1mut), sum(d1n))
  
  return(out)
}
