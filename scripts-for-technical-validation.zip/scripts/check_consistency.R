# Packages
require(tidyverse)
require(magrittr)
require(lubridate)

# Prepare links to read from github repo
yrs <- 2012:2022
hosts <- c("umana", "equidi", "uccelli-bersaglio", "uccelli-selvatici", "entomologica")
yrs_host <- expand_grid(yrs, hosts)
yrs_host %<>% filter(!(hosts %in% c("equidi", "uccelli-bersaglio", "uccelli-selvatici", "entomologica") & yrs < 2017)) %>% arrange(hosts, yrs)
yrs_host$hosts[grep("uccelli", yrs_host$hosts)] <- "uccelli"
fls_umana <- paste0("/wn-ita-province-sorveglianza-umana-", yrs, ".csv")
fls_umana_reg <- paste0("/wn-ita-regioni-sorveglianza-umana-", yrs, ".csv")
fls_birds1 <- paste0("/dati-sorveglianza-uccelli-bersaglio/wn-ita-sorveglianza-uccelli-bersaglio-", 2017:2022, ".csv")
fls_birds2 <- paste0("/dati-sorveglianza-uccelli-selvatici/wn-ita-sorveglianza-uccelli-selvatici-", 2017:2022, ".csv")
fls_equids <- paste0("/wn-ita-sorveglianza-equidi-", 2017:2022, ".csv")
fls_ento <- paste0("/wn-ita-sorveglianza-entomologica-", 2017:2022, ".csv")

links <- paste0("https://raw.githubusercontent.com/fbranda/west-nile/main/", c(yrs_host$yrs, yrs), 
                "/dati-sorveglianza-", c(yrs_host$hosts, rep("umana", 11)),
                c(fls_ento, fls_equids, fls_birds1, fls_birds2, fls_umana, fls_umana_reg))

# Read data
# Human
dat_wn_umana <- map_dfr(links[grep("province", links)], 
                        function(x){ as_tibble(data.table::fread(x)) %>% mutate(data = date(data), nuovi_casi = as.numeric(nuovi_casi)) }) # province

dat_wn_umana_reg <- map_dfr(links[grep("region", links)], 
                            function(x){ as_tibble(data.table::fread(x)) %>% mutate(data = date(data), nuovi_casi = as.numeric(nuovi_casi)) })

# Compute totals by region, monitoring week and type of infections, starting from cases at the province level
summ_prov <- dat_wn_umana %>% group_by(data, denominazione_regione, tipo_infezione) %>% summarise(TotP = sum(nuovi_casi, na.rm = T)) %>% ungroup()

# Check when aggregated data from the province level do not match the ones at the regional level: MISMATCH ONLY!
dat_wn_umana_reg %>% select(data, denominazione_regione, tipo_infezione, nuovi_casi) %>%
  left_join(summ_prov) %>%
  mutate(Check = nuovi_casi == TotP) %>%
  filter(!Check|is.na(Check))

# Check missing
dat_wn_umana %>% filter(is.na(nuovi_casi)) # from the first differences
dat_wn_umana_reg %>% filter(is.na(codice_regione)) # ok
dat_wn_umana_reg %>% filter(is.na(nuovi_casi)) # from the first differences


# Equids
dat_wn_equids <- map_dfr(links[grep("equid", links)], 
                         function(x){ as_tibble(data.table::fread(x)) %>% 
                             mutate(data = date(data), nuovi_casi = as.numeric(nuovi_casi), nuovi_morti_abbattuti = as.numeric(nuovi_morti_abbattuti)) })
summary(dat_wn_equids)
sum(is.na(dat_wn_equids)) # ok
dat_wn_equids %>% filter(is.na(nuovi_casi)) # from first differences

# Mosquito
dat_wn_ento <- map_dfr(links[grep("entomo", links)], 
                       function(x){ as_tibble(data.table::fread(x)) %>% mutate(data = date(data), nuovi_casi = as.numeric(nuovi_casi)) })
summary(dat_wn_ento)
sum(is.na(dat_wn_ento)) # ok
dat_wn_ento %>% filter(is.na(nuovi_casi)) # from first differences

# Birds 1
dat_wn_birds1 <- map_dfr(links[grep("bersaglio", links)], 
                         function(x){ as_tibble(data.table::fread(x)) %>% mutate(data = date(data), nuovi_casi = as.numeric(nuovi_casi)) })

# Birds 2
dat_wn_birds2 <- map_dfr(links[grep("selvatici", links)], 
                         function(x){ as_tibble(data.table::fread(x)) %>% mutate(data = date(data), nuovi_casi = as.numeric(nuovi_casi)) })

dat_wn_birds <- bind_rows(dat_wn_birds1, dat_wn_birds2)

summary(dat_wn_birds)
sum(is.na(dat_wn_birds)) # N. of missing
dat_wn_birds %>% filter(is.na(nuovi_casi)) # These comes from the computation of first differences
dat_wn_birds %>% filter(is.na(specie)) # Missing species only for 2021 as expected

